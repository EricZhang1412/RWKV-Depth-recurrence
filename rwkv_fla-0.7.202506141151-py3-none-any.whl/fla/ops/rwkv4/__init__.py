# -*- coding: utf-8 -*-

from .fused_recurrent import fused_recurrent_rwkv4

__all__ = [
    'fused_recurrent_rwkv4'
]
