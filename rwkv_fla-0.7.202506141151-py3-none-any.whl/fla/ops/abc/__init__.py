# -*- coding: utf-8 -*-

from .chunk import chunk_abc

__all__ = [
    'chunk_abc'
]
