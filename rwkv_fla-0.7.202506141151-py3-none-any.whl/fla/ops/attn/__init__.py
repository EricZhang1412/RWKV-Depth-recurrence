# -*- coding: utf-8 -*-

from .parallel import parallel_attn

__all__ = [
    'parallel_attn'
]
