# -*- coding: utf-8 -*-

from .naive import chunk_titans_linear

__all__ = [
    'chunk_titans_linear'
]
