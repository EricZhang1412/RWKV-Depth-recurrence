# -*- coding: utf-8 -*-

from .parallel import parallel_rebased

__all__ = [
    'parallel_rebased'
]
